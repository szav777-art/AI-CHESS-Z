# AI-CHESS-Z 1.4.4 — Engine diagnostics

- Version bumped to 1.4.4 (versionCode 29).
- Improved diagnosis for Android `error=13 / Permission denied`: distinguishes a valid imported ELF from the OS refusing execution from app-private storage.
- Error message explicitly warns that re-import/chmod do not solve Android 14 noexec restrictions and identifies the need for an Engine Host or packaged native engine.
- No chess engine is bundled in this shell ZIP; engines remain separately supplied.
- Important: this diagnostic release does not yet provide a compatible runtime for arbitrary imported ELF binaries. Do not treat it as a fix for engine execution.
