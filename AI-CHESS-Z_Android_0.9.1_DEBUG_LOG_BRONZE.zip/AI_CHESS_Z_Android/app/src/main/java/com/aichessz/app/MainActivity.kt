package com.aichessz.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.contract.ActivityResultContracts.CreateDocument
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.aichessz.app.engine.UciEngine
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Square
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.BufferedInputStream
import java.io.FileInputStream
import java.util.zip.GZIPInputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { AiChessZApp() } }
}

private val lightSquare = Color(0xFFE8E9E7)
private val darkSquare = Color(0xFF788794)
private val whitePiece = Color(0xFFAD7944) // Dark bronze; preserves the existing glyph style
private val blackPiece = Color(0xFF17211D)
private val whiteSymbols = mapOf("WHITE_KING" to "♔", "WHITE_QUEEN" to "♕", "WHITE_ROOK" to "♖", "WHITE_BISHOP" to "♗", "WHITE_KNIGHT" to "♘", "WHITE_PAWN" to "♙")
private val blackSymbols = mapOf("BLACK_KING" to "♚", "BLACK_QUEEN" to "♛", "BLACK_ROOK" to "♜", "BLACK_BISHOP" to "♝", "BLACK_KNIGHT" to "♞", "BLACK_PAWN" to "♟")

@Composable
private fun AiChessZApp() {
    val context = LocalContext.current
    val board = remember { Board() }
    val scope = rememberCoroutineScope()
    var revision by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<String?>(null) }
    var lastMove by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("Готово. Выберите фигуру или подключите движок в настройках.") }
    var engineFile by remember { mutableStateOf<File?>(null) }
    var engineName by remember { mutableStateOf("Движок не выбран") }
    var engineReady by remember { mutableStateOf(false) }
    var depth by remember { mutableFloatStateOf(12f) }
    var thinkSeconds by remember { mutableFloatStateOf(5f) }
    var hashMb by remember { mutableFloatStateOf(128f) }
    var threads by remember { mutableFloatStateOf(2f) }
    var multiPv by remember { mutableIntStateOf(1) }
    var combat by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var boardFlipped by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var debugEnabled by remember { mutableStateOf(true) }
    var debugLines by remember { mutableStateOf(listOf("Debug log создан")) }
    fun logEvent(message: String) { if (debugEnabled) debugLines = (debugLines + "${java.time.LocalTime.now()}  $message").takeLast(1000) }
    val exportLog = rememberLauncherForActivityResult(CreateDocument("text/plain")) { uri ->
        if (uri != null) scope.launch { runCatching { withContext(Dispatchers.IO) { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(debugLines.joinToString("\n")) } } }.onSuccess { status = "Журнал экспортирован" }.onFailure { status = "Ошибка экспорта лога: ${it.message}" } }
    }
    var engine by remember { mutableStateOf<UciEngine?>(null) }
    val legalMoves = remember(revision) { board.legalMoves() }
    val targets = remember(selected, revision) { legalMoves.filter { selected != null && it.toString().lowercase().startsWith(selected!!) }.map { it.toString().substring(2,4).lowercase() }.toSet() }
    val fen = remember(revision) { board.getFen() }

    val pickEngine = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                busy = true; engineReady = false; logEvent("Импорт движка начат: $uri")
                try {
                    val dir = File(context.filesDir, "engines").apply { mkdirs() }
                    val name = (uri.lastPathSegment ?: "engine").substringAfterLast('/').substringAfterLast(':').replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "engine.bin" }
                    val imported = File(dir, "imported_engine")
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri).use { input ->
                            requireNotNull(input) { "Не удалось открыть выбранный файл" }
                            if (name.endsWith(".tar.gz", true) || name.endsWith(".tgz", true)) {
                                extractTarGzEngine(input, imported)
                            } else {
                                imported.outputStream().use { output -> input.copyTo(output) }
                            }
                        }
                        require(imported.isFile && imported.length() > 1024) { "В архиве не найден исполняемый файл движка" }
                        imported.setExecutable(true, true)
                    }
                    val candidate = UciEngine(imported, dir)
                    logEvent("Файл скопирован: ${imported.absolutePath}, размер=${imported.length()}, executable=${imported.canExecute()}")
                    val smoke = candidate.selfTest()
                    logEvent("Smoke-test: ${smoke.joinToString(" | ")}")
                    require(smoke.any { it.startsWith("bestmove ") }) { "Движок не прошёл тестовый расчёт bestmove" }
                    candidate.close()
                    val readyCandidate = UciEngine(imported, dir)
                    val handshake = readyCandidate.start()
                    require(handshake.any { it.trim() == "uciok" }) { "Файл не ответил на протокол UCI" }
                    readyCandidate.isReady()
                    engine?.let { runCatching { it.close() } }
                    engine = readyCandidate; engineFile = imported; engineName = handshake.firstOrNull { it.startsWith("id name ") }?.removePrefix("id name ") ?: imported.name; engineReady = true
                    status = "Движок проверен: UCI + тестовый bestmove. Подключён: $engineName"; logEvent("Движок подключён: $engineName")
                } catch (e: Exception) {
                    engineReady = false; engine = null; logEvent("ОШИБКА импорта/запуска: ${e.stackTraceToString()}")
                    status = "Не удалось запустить движок: ${e.message ?: e.javaClass.simpleName}. Нужен исполняемый Android-бинарник, совместимый с телефоном, и протокол UCI."
                } finally { busy = false }
            }
        }
    }

    MaterialTheme {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF171C1A)) {
            LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("AI-CHESS-Z", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                            Text("LOCAL ENGINE · UCI · OFFLINE", color = Color(0xFFB9C5BE), fontSize = 11.sp)
                        }
                        Button(onClick = { showSettings = !showSettings }) { Text(if (showSettings) "К доске" else "Настройки") }
                    }
                }
                if (showSettings) {
                    item { SettingPanel(
                        engineName = engineName, engineReady = engineReady, depth = depth, onDepth = { depth = it }, seconds = thinkSeconds, onSeconds = { thinkSeconds = it }, hash = hashMb, onHash = { hashMb = it }, threads = threads, onThreads = { threads = it }, multiPv = multiPv, onMultiPv = { multiPv = it }, combat = combat, onCombat = { combat = it }, onPick = { pickEngine.launch(arrayOf("*/*")) }, debugEnabled = debugEnabled, onDebugEnabled = { debugEnabled = it; logEvent("Debug log ${if (it) "включён" else "выключен"}") }, onExportLog = { exportLog.launch("AI-CHESS-Z-debug-log.txt") }, onClearLog = { debugLines = listOf("${java.time.LocalTime.now()}  Журнал очищен") }, debugLines = debugLines, onTest = {
                            val e = engine
                            if (e == null || !engineReady) status = "Сначала выберите совместимый UCI-движок."
                            else scope.launch {
                                busy = true
                                try {
                                    e.setOption("Threads", (if (combat) threads.toInt().coerceAtLeast(2) else threads.toInt()).toString()); e.setOption("Hash", hashMb.toInt().toString()); e.setOption("MultiPV", (if (combat) 1 else multiPv).toString()); e.isReady()
                                    status = "Настройки переданы движку. Нажмите «Ход компьютера» для проверки расчёта."
                                } catch (ex: Exception) { status = "Ошибка настройки: ${ex.message}" } finally { busy = false }
                            }
                        }) }
                } else {
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { boardFlipped = !boardFlipped }) { Text(if (boardFlipped) "Ориентация: чёрные снизу" else "Перевернуть доску") }
                            OutlinedButton(onClick = { selected = null; status = "Выберите фигуру, затем поле назначения." }) { Text("Снять выбор") }
                        }
                    }
                    item {
                        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                            Column(Modifier.fillMaxWidth().aspectRatio(1f)) {
                                for (visualRank in 0..7) Row(Modifier.weight(1f)) {
                                    val rank = if (boardFlipped) visualRank + 1 else 8 - visualRank
                                    for (visualFile in 0..7) {
                                        val file = if (boardFlipped) 'H' - visualFile else 'A' + visualFile
                                        val sq = "$file$rank"; val low = sq.lowercase()
                                        val pieceName = board.getPiece(Square.valueOf(sq)).toString()
                                        val symbol = whiteSymbols[pieceName] ?: blackSymbols[pieceName] ?: ""
                                        val base = if (((file - 'A') + rank) % 2 == 0) darkSquare else lightSquare
                                        val bg = when { selected == low -> Color(0xFFE5B84B); low in targets -> Color(0xFFB5D69C); lastMove?.let { low == it.take(2) || low == it.substring(2,4) } == true -> Color(0xFF9EBAA1); else -> base }
                                        Box(Modifier.weight(1f).aspectRatio(1f).background(bg).clickable {
                                            val current = selected
                                            if (current == null) {
                                                val piece = board.getPiece(Square.valueOf(sq)).toString(); val whiteTurn = board.getSideToMove().toString() == "WHITE"
                                                if (piece.startsWith(if (whiteTurn) "WHITE" else "BLACK")) selected = low
                                            } else {
                                                val move = legalMoves.firstOrNull { it.toString().lowercase().startsWith(current + low) && (it.toString().length <= 4 || it.toString().endsWith("q", true)) }
                                                if (move != null) { runCatching { board.doMove(move) }.onSuccess { lastMove = move.toString().lowercase(); revision++; status = "Ход ${move.toString().lowercase()} · ${if (board.isMated()) "мат" else "ход ${board.getSideToMove()}"}" }; selected = null }
                                                else { val piece = board.getPiece(Square.valueOf(sq)).toString(); val whiteTurn = board.getSideToMove().toString() == "WHITE"; selected = if (piece.startsWith(if (whiteTurn) "WHITE" else "BLACK")) low else null }
                                            }
                                        }, contentAlignment = Alignment.Center) {
                                            if (symbol.isNotEmpty()) {
                                                if (pieceName.startsWith("WHITE")) {
                                                    // Dark underlay creates a clean outline without changing the Unicode piece style.
                                                    Text(symbol, color = Color(0xFF26312B), fontSize = 35.sp, fontWeight = FontWeight.Black)
                                                    Text(symbol, color = whitePiece, fontSize = 29.sp, fontWeight = FontWeight.Black)
                                                } else {
                                                    Text(symbol, color = blackPiece, fontSize = 30.sp, fontWeight = FontWeight.Black)
                                                }
                                            }
                                            if (low in targets && symbol.isEmpty()) Box(Modifier.size(14.dp).background(Color(0x99556B45)))
                                        }
                                    }
                                }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (boardFlipped) "h g f e d c b a" else "a b c d e f g h", color = Color(0xFFCFD8D2), fontSize = 12.sp)
                            }
                        }
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Button(modifier = Modifier.weight(1f), enabled = !busy && engineReady, onClick = {
                                val e = engine
                                if (e != null) scope.launch {
                                    busy = true
                                    try {
                                        e.setOption("Threads", threads.toInt().toString()); e.setOption("Hash", hashMb.toInt().toString()); e.setOption("MultiPV", (if (combat) 1 else multiPv).toString()); e.isReady()
                                        e.setPosition(fen)
                                        val moveText = e.bestMove(fen, depth.toInt(), thinkSeconds.toLong() * 1000L)
                                        val move = board.legalMoves().firstOrNull { it.toString().equals(moveText, true) }
                                        if (move == null) status = "Движок вернул ход '$moveText', который не распознан как легальный."
                                        else { board.doMove(move); lastMove = move.toString().lowercase(); selected = null; revision++; status = "Движок сыграл ${moveText}." }
                                    } catch (ex: Exception) { status = "Ошибка движка: ${ex.message}" } finally { busy = false }
                                }
                            }) { Text(if (busy) "Расчёт…" else "Ход компьютера") }
                            Button(modifier = Modifier.weight(1f), onClick = { board.loadFromFen(Board().getFen()); selected = null; lastMove = null; revision++; status = "Новая партия. Белые ходят первыми." }) { Text("Новая партия") }
                        }
                    }
                    item { Button(modifier = Modifier.fillMaxWidth(), onClick = { showSettings = true }) { Text("Настройки и движки") } }
                }
                item {
                    Column(Modifier.fillMaxWidth().background(Color(0xFF242C28)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("СТАТУС", color = Color.White, fontWeight = FontWeight.Bold)
                        Text(status, color = Color(0xFFD9E2DC), fontSize = 13.sp)
                        Text("Движок: $engineName", color = Color(0xFFB9C5BE), fontSize = 12.sp)
                        Text("FEN: $fen", color = Color(0xFFB9C5BE), fontSize = 10.sp)
                    }
                }
                item { Text("Импорт поддерживает исполняемый Android-бинарник и .tar.gz/.tgz с бинарником внутри. После импорта приложение проверяет UCI и тестовый bestmove. Windows .exe, APK и архив только с исходниками не являются готовым движком.", color = Color(0xFFB9C5BE), fontSize = 11.sp) }
            }
        }
    }
}

/** Extracts the first plausible regular executable from a gzip-compressed TAR archive. */
private fun extractTarGzEngine(input: java.io.InputStream, destination: File) {
    GZIPInputStream(BufferedInputStream(input)).use { gz ->
        val header = ByteArray(512)
        var extracted = false
        while (true) {
            var read = 0
            while (read < 512) {
                val n = gz.read(header, read, 512 - read)
                if (n < 0) break
                read += n
            }
            if (read == 0 || read < 512 || header.all { it == 0.toByte() }) break
            fun field(offset: Int, length: Int): String = String(header, offset, length, Charsets.UTF_8).trimEnd('\u0000', ' ')
            val name = field(0, 100)
            val prefix = field(345, 155)
            val fullName = if (prefix.isBlank()) name else "$prefix/$name"
            val sizeText = field(124, 12).trim()
            val size = sizeText.toLongOrNull(8) ?: 0L
            val type = header[156].toInt().toChar()
            val executableCandidate = type == '\u0000' || type == '0'
            val plausible = executableCandidate && size > 1024 && !name.endsWith("/") &&
                name.substringAfterLast('/').contains("stockfish", true)
            if (!extracted && plausible) {
                destination.outputStream().buffered().use { out ->
                    var remaining = size
                    val buffer = ByteArray(64 * 1024)
                    while (remaining > 0) {
                        val n = gz.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                        if (n < 0) error("Архив оборван внутри файла $fullName")
                        out.write(buffer, 0, n); remaining -= n
                    }
                }
                extracted = true
            } else {
                var remaining = size
                val buffer = ByteArray(64 * 1024)
                while (remaining > 0) {
                    val n = gz.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                    if (n < 0) error("Повреждён TAR-архив")
                    remaining -= n
                }
            }
            val padding = (512 - (size % 512)) % 512
            var skip = padding
            while (skip > 0) {
                val n = gz.skip(skip)
                if (n <= 0L) { if (gz.read() < 0) error("Повреждён TAR-архив"); skip-- } else skip -= n
            }
            if (extracted) break
        }
        require(extracted) { "В .tar.gz не найден обычный файл-бинарник" }
    }
}

@Composable
private fun SettingPanel(
    engineName: String, engineReady: Boolean, depth: Float, onDepth: (Float) -> Unit,
    seconds: Float, onSeconds: (Float) -> Unit, hash: Float, onHash: (Float) -> Unit,
    threads: Float, onThreads: (Float) -> Unit, multiPv: Int, onMultiPv: (Int) -> Unit,
    combat: Boolean, onCombat: (Boolean) -> Unit, onPick: () -> Unit, debugEnabled: Boolean, onDebugEnabled: (Boolean) -> Unit, onExportLog: () -> Unit, onClearLog: () -> Unit, debugLines: List<String>, onTest: () -> Unit
) {
    Column(Modifier.fillMaxWidth().background(Color(0xFF242C28)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text("ДВИЖКИ И РАСЧЁТ", color = Color.White, fontWeight = FontWeight.Bold)
        Text("Текущий движок: $engineName · ${if (engineReady) "готов" else "не подключён"}", color = Color(0xFFD9E2DC), fontSize = 12.sp)
        Button(modifier = Modifier.fillMaxWidth(), onClick = onPick) { Text("Загрузить / выбрать файл движка") }
        Text("Глубина: ${depth.toInt()} полуходов", color = Color.White); Slider(value = depth, onValueChange = onDepth, valueRange = 1f..40f, steps = 38)
        Text("Время на ход: ${seconds.toInt()} с (резерв для timed search)", color = Color.White); Slider(value = seconds, onValueChange = onSeconds, valueRange = 1f..60f, steps = 58)
        Text("Память Hash: ${hash.toInt()} МБ", color = Color.White); Slider(value = hash, onValueChange = onHash, valueRange = 16f..1024f, steps = 62)
        Text("Потоки CPU: ${threads.toInt()}", color = Color.White); Slider(value = threads, onValueChange = onThreads, valueRange = 1f..8f, steps = 6)
        Text("Главные варианты (MultiPV)", color = Color.White)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { (1..3).forEach { n -> FilterChip(selected = multiPv == n, onClick = { onMultiPv(n) }, label = { Text("$n") }) } }
        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = combat, onCheckedChange = onCombat); Text("Режим максимальной силы", color = Color.White) }
        Text("Режим максимальной силы фиксирует 1 вариант и максимизирует потоки в рамках выбранного лимита; не гарантирует максимальную силу на перегретом телефоне.", color = Color(0xFFB9C5BE), fontSize = 11.sp)
        Divider()
        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = debugEnabled, onCheckedChange = onDebugEnabled); Text("Вести журнал отладки", color = Color.White) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick = onExportLog) { Text("Экспортировать лог") }; OutlinedButton(onClick = onClearLog) { Text("Очистить") } }
        Text("Последние события:", color = Color.White, fontWeight = FontWeight.SemiBold)
        Text(debugLines.takeLast(12).joinToString("\n"), color = Color(0xFFB9C5BE), fontSize = 10.sp)
        Button(modifier = Modifier.fillMaxWidth(), onClick = onTest, enabled = engineReady) { Text("Применить настройки движка") }
    }
}
