package com.aichessz.app

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.contract.ActivityResultContracts.CreateDocument
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.aichessz.app.engine.UciEngine
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Square
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.BufferedInputStream
import java.io.FileInputStream
import java.util.zip.GZIPInputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { AiChessZApp() } }
}

private val lightSquare = Color(0xFFE9E7E2)
private val darkSquare = Color(0xFF87918D) // Lighter charcoal-sage for clearer square orientation
private val whitePiece = Color(0xFF654126) // Dark bronze filled white pieces
private val blackPiece = Color(0xFF17211D)
private val whiteSymbols = mapOf("WHITE_KING" to "♔", "WHITE_QUEEN" to "♕", "WHITE_ROOK" to "♖", "WHITE_BISHOP" to "♗", "WHITE_KNIGHT" to "♘", "WHITE_PAWN" to "♙")
private val blackSymbols = mapOf("BLACK_KING" to "♚", "BLACK_QUEEN" to "♛", "BLACK_ROOK" to "♜", "BLACK_BISHOP" to "♝", "BLACK_KNIGHT" to "♞", "BLACK_PAWN" to "♟")

@Composable
private fun AiChessZApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("aichessz_state", android.content.Context.MODE_PRIVATE) }
    val restoredHistory = remember {
        runCatching { prefs.getString("move_history", null)?.split("\n")?.filter { it.isNotBlank() }?.takeIf { it.isNotEmpty() } }
            .getOrNull() ?: listOf(Board().getFen())
    }
    val restoredIndex = remember { prefs.getInt("history_index", restoredHistory.lastIndex).coerceIn(0, restoredHistory.lastIndex) }
    val board = remember { Board().apply { runCatching { loadFromFen(restoredHistory[restoredIndex]) } } }
    val scope = rememberCoroutineScope()
    var revision by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<String?>(null) }
    var lastMove by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("Готово. Выберите фигуру или подключите движок в настройках.") }
    var fenInput by remember { mutableStateOf("") }
    var engineFile by remember { mutableStateOf<File?>(null) }
    var engineName by remember { mutableStateOf("Движок не выбран") }
    var engineOptionDescriptions by remember { mutableStateOf(listOf<String>()) }
    var engineReady by remember { mutableStateOf(false) }
    var depth by remember { mutableFloatStateOf(prefs.getFloat("depth", 12f)) }
    var thinkSeconds by remember { mutableFloatStateOf(prefs.getFloat("think_seconds", 5f)) }
    var hashMb by remember { mutableFloatStateOf(prefs.getFloat("hash_mb", 128f)) }
    var threads by remember { mutableFloatStateOf(prefs.getFloat("threads", 2f)) }
    var multiPv by remember { mutableIntStateOf(prefs.getInt("multi_pv", 1)) }
    var skillLevel by remember { mutableIntStateOf(prefs.getInt("skill_level", 20).coerceIn(0, 20)) }
    var combat by remember { mutableStateOf(prefs.getBoolean("combat", false)) }
    var showSettings by remember { mutableStateOf(false) }
    var showEngineSettings by remember { mutableStateOf(false) }
    var gameMode by remember { mutableStateOf(prefs.getString("game_mode", "Человек против человека") ?: "Человек против человека") }
    var moveHistory by remember { mutableStateOf(restoredHistory) }
    var historyIndex by remember { mutableIntStateOf(restoredIndex) }
    var analysisRunning by remember { mutableStateOf(false) }
    var analysisInfo by remember { mutableStateOf("Анализ выключен") }
    var analysisLines by remember { mutableStateOf(listOf<String>()) }
    var analysisStartedAt by remember { mutableLongStateOf(0L) }
    var boardFlipped by remember { mutableStateOf(prefs.getBoolean("board_flipped", false)) }
    var busy by remember { mutableStateOf(false) }
    var debugEnabled by remember { mutableStateOf(true) }
    val logDir = remember { File(context.filesDir, "logs").apply { mkdirs() } }
    val logFile = remember { File(logDir, "debug-log-${java.time.LocalDate.now()}.txt") }
    var debugLines by remember { mutableStateOf(runCatching {
        logDir.listFiles()?.filter { it.isFile && it.name.startsWith("debug-log-") && it.name.endsWith(".txt") }
            ?.sortedBy { it.name }?.takeLast(7)?.flatMap { it.readLines() }?.takeLast(5000)
            ?.ifEmpty { listOf("Debug log создан") } ?: listOf("Debug log создан")
    }.getOrDefault(listOf("Debug log создан"))) }
    fun logEvent(message: String) {
        if (debugEnabled) {
            val entry = "${java.time.LocalDateTime.now()}  $message"
            val updated = (debugLines + entry).takeLast(5000)
            debugLines = updated
            runCatching {
                logFile.appendText(entry + "\n")
                val cutoff = java.time.LocalDate.now().minusDays(7).toString()
                logDir.listFiles()?.filter { it.name.startsWith("debug-log-") && it.name.endsWith(".txt") && it.name.removePrefix("debug-log-").removeSuffix(".txt") < cutoff }?.forEach { it.delete() }
            }
        }
    }
    LaunchedEffect(moveHistory, historyIndex, gameMode, boardFlipped, depth, thinkSeconds, hashMb, threads, multiPv, skillLevel, combat) {
        runCatching {
            prefs.edit().putString("move_history", moveHistory.joinToString("\n"))
                .putInt("history_index", historyIndex.coerceIn(0, moveHistory.lastIndex))
                .putString("game_mode", gameMode).putBoolean("board_flipped", boardFlipped)
                .putFloat("depth", depth).putFloat("think_seconds", thinkSeconds)
                .putFloat("hash_mb", hashMb).putFloat("threads", threads)
                .putInt("multi_pv", multiPv).putInt("skill_level", skillLevel).putBoolean("combat", combat).apply()
        }
    }
    val exportLog = rememberLauncherForActivityResult(CreateDocument("text/plain")) { uri ->
        if (uri != null) scope.launch { runCatching { withContext(Dispatchers.IO) { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(debugLines.joinToString("\n")) } } }.onSuccess { status = "Журнал экспортирован" }.onFailure { status = "Ошибка экспорта лога: ${it.message}" } }
    }
    var engine by remember { mutableStateOf<UciEngine?>(null) }
    LaunchedEffect(Unit) {
        val savedPath = prefs.getString("engine_path", null)
        val savedName = prefs.getString("engine_name", "Stockfish") ?: "Stockfish"
        if (!savedPath.isNullOrBlank()) {
            val savedExecutable = File(savedPath)
            if (savedExecutable.isFile && savedExecutable.canExecute()) {
                runCatching {
                    val candidate = UciEngine(savedExecutable, savedExecutable.parentFile ?: context.filesDir)
                    val hello = candidate.start()
                    require(hello.any { it.trim() == "uciok" }) { "Нет ответа UCI" }
                    candidate.isReady()
                    engine = candidate; engineFile = savedExecutable; engineOptionDescriptions = candidate.advertisedOptions(); engineName = hello.firstOrNull { it.startsWith("id name ") }?.removePrefix("id name ") ?: savedName
                    engineReady = true; status = "Сохранённый движок восстановлен: $engineName"
                    logEvent("Движок автоматически восстановлен после запуска: $engineName")
                }.onFailure {
                    engineReady = false; engine = null
                    status = "Партия восстановлена; движок не запустился: ${it.message}"
                    logEvent("Ошибка автоматического восстановления движка: ${it.stackTraceToString()}")
                }
            }
        }
    }
    suspend fun recoverSavedEngine(): Boolean {
        val path = prefs.getString("engine_path", null) ?: return false
        val executable = File(path)
        if (!executable.isFile || !executable.canExecute()) return false
        return runCatching {
            runCatching { engine?.close() }
            val candidate = UciEngine(executable, executable.parentFile ?: context.filesDir)
            val hello = candidate.start()
            require(hello.any { it.trim() == "uciok" }) { "Нет ответа UCI при восстановлении" }
            candidate.isReady()
            engine = candidate
            engineOptionDescriptions = candidate.advertisedOptions()
            engineFile = executable
            engineName = hello.firstOrNull { it.startsWith("id name ") }?.removePrefix("id name ") ?: "Stockfish"
            engineReady = true
            logEvent("Движок восстановлен после сбоя: $engineName")
            true
        }.getOrElse {
            engine = null
            engineReady = false
            logEvent("Не удалось восстановить движок: ${it.stackTraceToString()}")
            false
        }
    }

    val legalMoves = remember(revision) { board.legalMoves() }
    val targets = remember(selected, revision) { legalMoves.filter { selected != null && it.toString().lowercase().startsWith(selected!!) }.map { it.toString().substring(2,4).lowercase() }.toSet() }
    val fen = remember(revision) { board.getFen() }

    val pickEngine = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                busy = true; logEvent("Импорт движка начат: $uri")
                try {
                    val dir = File(context.filesDir, "engines").apply { mkdirs() }
                    // Document-provider URIs often contain IDs (for example msf:123), not filenames.
                    // Query the provider's real display name so .tar.gz/.tgz archives are recognized.
                    val displayName = withContext(Dispatchers.IO) {
                        runCatching {
                            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                                if (cursor.moveToFirst()) {
                                    val column = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                                    if (column >= 0) cursor.getString(column) else null
                                } else null
                            }
                        }.getOrNull()
                    }
                    val name = (displayName ?: uri.lastPathSegment ?: "engine")
                        .substringAfterLast('/').substringAfterLast(':')
                        .replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "engine.bin" }
                    val imported = File(dir, "imported_engine_${System.currentTimeMillis()}")
                    logEvent("Имя выбранного файла: $name")
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri).use { input ->
                            requireNotNull(input) { "Не удалось открыть выбранный файл" }
                            if (name.endsWith(".tar.gz", true) || name.endsWith(".tgz", true)) {
                                extractTarGzEngine(input, imported)
                            } else {
                                imported.outputStream().use { output -> input.copyTo(output) }
                            }
                        }
                        require(imported.isFile && imported.length() > 1_000_000L) { "Файл слишком мал для движка. Выберите Stockfish Android ARM64 или архив .tar.gz/.tgz." }
                        val magic = imported.inputStream().use { input -> ByteArray(4).also { require(input.read(it) == 4) } }
                        require(magic.contentEquals(byteArrayOf(0x7f, 0x45, 0x4c, 0x46))) { "Выбранный файл не является Android ELF-бинарником. Документ, RTF, APK и исходники не принимаются." }
                        imported.setExecutable(true, true)
                    }
                    val candidate = UciEngine(imported, dir)
                    logEvent("Файл скопирован: ${imported.absolutePath}, размер=${imported.length()}, executable=${imported.canExecute()}")
                    val smoke = candidate.selfTest()
                    logEvent("Smoke-test: ${smoke.joinToString(" | ")}")
                    require(smoke.any { it.startsWith("bestmove ") }) { "Движок не прошёл тестовый расчёт bestmove" }
                    candidate.close()
                    val readyCandidate = UciEngine(imported, dir)
                    val handshake = readyCandidate.start()
                    require(handshake.any { it.trim() == "uciok" }) { "Файл не ответил на протокол UCI" }
                    readyCandidate.isReady()
                    engine?.let { runCatching { it.close() } }
                    engine = readyCandidate; engineOptionDescriptions = readyCandidate.advertisedOptions(); engineFile = imported; prefs.edit().putString("engine_path", imported.absolutePath).putString("engine_name", handshake.firstOrNull { it.startsWith("id name ") }?.removePrefix("id name ") ?: imported.name).apply(); engineName = handshake.firstOrNull { it.startsWith("id name ") }?.removePrefix("id name ") ?: imported.name; engineReady = true
                    status = "Движок проверен: UCI + тестовый bestmove. Подключён: $engineName"; logEvent("Движок подключён: $engineName")
                } catch (e: Exception) {
                    logEvent("ОШИБКА импорта/запуска: ${e.stackTraceToString()}")
                    status = "Не удалось запустить движок: ${e.message ?: e.javaClass.simpleName}. Нужен исполняемый Android-бинарник, совместимый с телефоном, и протокол UCI."
                } finally { busy = false }
            }
        }
    }

    MaterialTheme {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF171C1A)) {
            LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("AI-CHESS-Z", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
                            Text("${if (engineReady) engineName else "Движок не выбран"} · ${if (engineReady) "ГОТОВ" else "НЕ ПОДКЛЮЧЁН"}", color = if (engineReady) Color(0xFF8FE0B0) else Color(0xFFFFB4AB), fontSize = 10.sp)
                            Text("♙  Человек     ${if (gameMode == "Человек против движка") "⚙  Движок" else "♙  Игрок 2"}   ·   ${if (analysisRunning) "АНАЛИЗ" else "ГОТОВ"}", color = Color(0xFFB9C5BE), fontSize = 10.sp)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            IconButton(onClick = { showSettings = !showSettings; showEngineSettings = false }) { Text("♙", color = Color.White, fontSize = 21.sp) }
                            IconButton(onClick = { showEngineSettings = !showEngineSettings; showSettings = false }) { Text("⚙", color = Color(0xFFE1B66B), fontSize = 21.sp) }
                        }
                    }
                }
                if (showSettings) {
                    item { GeneralSettingsPanel(gameMode = gameMode, onGameMode = { gameMode = it }, onClose = { showSettings = false }) }
                } else if (showEngineSettings) {
                    item { SettingPanel(
                        engineName = engineName, engineReady = engineReady, optionDescriptions = engineOptionDescriptions, depth = depth, onDepth = { depth = it }, seconds = thinkSeconds, onSeconds = { thinkSeconds = it }, hash = hashMb, onHash = { hashMb = it }, threads = threads, onThreads = { threads = it }, multiPv = multiPv, onMultiPv = { multiPv = it }, skillLevel = skillLevel, onSkillLevel = { skillLevel = it }, combat = combat, onCombat = { combat = it }, onPick = { pickEngine.launch(arrayOf("*/*")) }, debugEnabled = debugEnabled, onDebugEnabled = { debugEnabled = it; logEvent("Debug log ${if (it) "включён" else "выключен"}") }, onExportLog = { exportLog.launch("AI-CHESS-Z-debug-log.txt") }, onClearLog = { debugLines = listOf("${java.time.LocalDateTime.now()}  Журнал очищен"); runCatching { logDir.listFiles()?.filter { it.name.startsWith("debug-log-") }?.forEach { it.delete() }; logFile.writeText(debugLines.joinToString("\n") + "\n") } }, debugLines = debugLines, onTest = {
                            val e = engine
                            if (e == null || !engineReady) status = "Сначала выберите совместимый UCI-движок."
                            else scope.launch {
                                busy = true
                                try {
                                    e.setOption("Threads", (if (combat) threads.toInt().coerceAtLeast(2) else threads.toInt()).toString()); e.setOption("Hash", hashMb.toInt().toString()); e.setOption("Skill Level", skillLevel.toString()); e.setOption("UCI_LimitStrength", "false"); e.setOption("MultiPV", (if (combat) 1 else multiPv).toString()); e.isReady()
                                    status = "Настройки переданы движку. Нажмите «Ход компьютера» для проверки расчёта."
                                } catch (ex: Exception) { status = "Ошибка настройки: ${ex.message}" } finally { busy = false }
                            }
                        }) }
                } else {
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Button(onClick = { board.loadFromFen(Board().getFen()); selected = null; lastMove = null; moveHistory = listOf(board.getFen()); historyIndex = 0; revision++; status = "Новая партия. Белые ходят первыми." }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)) { Text("＋ Новая", fontSize = 11.sp) }
                            OutlinedButton(onClick = { boardFlipped = !boardFlipped }, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 4.dp)) { Text("⇅", fontSize = 12.sp) }
                            Text("$gameMode", color = Color(0xFFCFD8D2), fontSize = 10.sp, modifier = Modifier.weight(1f))
                        }
                    }
                    item {
                        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                            Column(Modifier.fillMaxWidth().aspectRatio(1f)) {
                                for (visualRank in 0..7) Row(Modifier.weight(1f)) {
                                    val rank = if (boardFlipped) visualRank + 1 else 8 - visualRank
                                    for (visualFile in 0..7) {
                                        val file = if (boardFlipped) 'H' - visualFile else 'A' + visualFile
                                        val sq = "$file$rank"; val low = sq.lowercase()
                                        val pieceName = board.getPiece(Square.valueOf(sq)).toString()
                                        val symbol = whiteSymbols[pieceName] ?: blackSymbols[pieceName] ?: ""
                                        val base = if (((file - 'A') + rank) % 2 == 0) darkSquare else lightSquare
                                        val bg = when { selected == low -> Color(0xFFF3DFA0); lastMove?.let { low == it.take(2) || low == it.substring(2,4) } == true -> Color(0xFFE9D98B); low in targets -> base; else -> base }
                                        Box(Modifier.weight(1f).aspectRatio(1f).background(bg).clickable {
                                            val current = selected
                                            if (current == null) {
                                                val piece = board.getPiece(Square.valueOf(sq)).toString(); val whiteTurn = board.getSideToMove().toString() == "WHITE"
                                                if (piece.startsWith(if (whiteTurn) "WHITE" else "BLACK")) selected = low
                                            } else {
                                                val move = legalMoves.firstOrNull { it.toString().lowercase().startsWith(current + low) && (it.toString().length <= 4 || it.toString().endsWith("q", true)) }
                                                if (move != null) {
                                                    if (analysisRunning) { analysisRunning = false; scope.launch { runCatching { engine?.stopSearch() } } }
                                                    runCatching { board.doMove(move) }.onSuccess {
                                                        lastMove = move.toString().lowercase(); moveHistory = moveHistory.take(historyIndex + 1) + board.getFen(); historyIndex = moveHistory.lastIndex; revision++
                                                        status = "Ход ${move.toString().lowercase()} · ${if (board.isMated()) "мат" else "ход ${board.getSideToMove()}"}"
                                                        if (gameMode == "Человек против движка" && board.getSideToMove().toString() == "BLACK" && engineReady) {
                                                            val e = engine; val position = board.getFen(); busy = true
                                                            scope.launch {
                                                                try {
                                                                    e?.setOption("Threads", threads.toInt().coerceAtLeast(1).toString()); e?.setOption("Hash", hashMb.toInt().coerceAtLeast(16).toString()); e?.setOption("Skill Level", skillLevel.toString()); e?.setOption("UCI_LimitStrength", "false"); e?.setOption("MultiPV", (if (combat) 1 else multiPv).toString()); e?.isReady()
                                                                    val best = e?.bestMove(position, depth.toInt().coerceIn(1,40), thinkSeconds.toLong().coerceAtLeast(1) * 1000L)
                                                                    val reply = board.legalMoves().firstOrNull { it.toString().equals(best, true) }
                                                                    if (reply != null && board.getSideToMove().toString() == "BLACK") { board.doMove(reply); lastMove = reply.toString().lowercase(); moveHistory = moveHistory.take(historyIndex + 1) + board.getFen(); historyIndex = moveHistory.lastIndex; revision++; status = "Stockfish ответил: $best"; logEvent("Автоход движка: $best") }
                                                                    else { status = "Движок не вернул легальный ответ: $best"; logEvent(status) }
                                                                } catch (ex: Exception) { status = "Ошибка автохода: ${ex.message}"; logEvent("Ошибка автохода: ${ex.stackTraceToString()}"); if (recoverSavedEngine()) status = "Движок восстановлен. Повтори ход компьютера." } finally { busy = false }
                                                            }
                                                        }
                                                    }; selected = null
                                                }
                                                else { val piece = board.getPiece(Square.valueOf(sq)).toString(); val whiteTurn = board.getSideToMove().toString() == "WHITE"; selected = if (piece.startsWith(if (whiteTurn) "WHITE" else "BLACK")) low else null }
                                            }
                                        }, contentAlignment = Alignment.Center) {
                                            if (visualFile == 0) Text(rank.toString(), modifier = Modifier.align(Alignment.TopStart).padding(start = 2.dp, top = 1.dp), color = Color(0xFF171717), fontSize = 10.sp, fontWeight = FontWeight.Black)
                                            if (visualRank == 7) Text(file.lowercaseChar().toString(), modifier = Modifier.align(Alignment.BottomEnd).padding(end = 2.dp, bottom = 1.dp), color = Color(0xFF171717), fontSize = 10.sp, fontWeight = FontWeight.Black)
                                            if (symbol.isNotEmpty()) {
                                                if (pieceName.startsWith("WHITE")) {
                                                    // Dark underlay preserves the existing Unicode piece style with a bronze fill.
                                                    Text(symbol, color = Color(0xFF29251F), fontSize = 35.sp, fontWeight = FontWeight.Black)
                                                    Text(symbol, color = Color(0xFF9B6A3D), fontSize = 32.sp, fontWeight = FontWeight.Black)
                                                } else {
                                                    Text(symbol, color = blackPiece, fontSize = 32.sp, fontWeight = FontWeight.Black)
                                                }
                                            }
                                            if (low in targets && symbol.isEmpty()) Box(Modifier.size(5.dp).background(Color(0xFFDB9BB6), shape = androidx.compose.foundation.shape.CircleShape))
                                        }
                                    }
                                }
                            }

                        }
                    }
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                            IconButton(enabled = historyIndex > 0, onClick = { historyIndex--; board.loadFromFen(moveHistory[historyIndex]); selected = null; lastMove = null; revision++; status = "Переход к предыдущей позиции" }) { Text("|◀", color = Color.White, fontSize = 15.sp) }
                            IconButton(enabled = engineReady && !busy, onClick = {
                                val e = engine
                                if (e != null && !analysisRunning) {
                                    analysisRunning = true
                                    analysisLines = emptyList()
                                    analysisStartedAt = System.currentTimeMillis()
                                    analysisInfo = "Запуск анализа…"
                                    scope.launch {
                                        try {
                                            e.setOption("Threads", threads.toInt().coerceAtLeast(1).toString())
                                            e.setOption("Hash", hashMb.toInt().coerceAtLeast(16).toString())
                                            e.setOption("Skill Level", skillLevel.toString())
                                            e.setOption("UCI_LimitStrength", "false")
                                            e.setOption("MultiPV", (if (combat) 1 else multiPv).toString())
                                            e.isReady(); e.setPosition(fen); e.startInfiniteAnalysis()
                                            status = "Бесконечный анализ запущен"
                                            while (analysisRunning) {
                                                val line = e.nextLine() ?: break
                                                if (line.startsWith("info ") && line.contains(" pv ")) {
                                                    val score = Regex("score (cp|mate) (-?\\d+)").find(line)
                                                    val pv = line.substringAfter(" pv ", "").trim()
                                                    val depthValue = Regex("depth (\\d+)").find(line)?.groupValues?.get(1) ?: "?"
                                                    val multipvValue = Regex("multipv (\\d+)").find(line)?.groupValues?.get(1)?.toIntOrNull() ?: 1
                                                    val rawScore = score?.groupValues?.get(2)?.toIntOrNull()
                                                    val whitePovScore = if (rawScore != null && board.getSideToMove().toString() == "BLACK") -rawScore else rawScore
                                                    val evaluation = if (score == null) "оценка …" else if (score.groupValues[1] == "mate") "мат ${if (board.getSideToMove().toString() == "BLACK") -(rawScore ?: 0) else rawScore}" else "${if ((whitePovScore ?: 0) >= 0) "+" else ""}${"%.2f".format(java.util.Locale.US, (whitePovScore ?: 0) / 100.0)}"
                                                    val moveNo = fen.split(" ").getOrNull(5)?.toIntOrNull() ?: 1
                                                    val row = "#$multipvValue  $moveNo ход · depth $depthValue · $evaluation\n$pv"
                                                    analysisLines = (analysisLines.filterNot { it.startsWith("#$multipvValue  ") } + row).sortedBy { it.substringAfter('#').substringBefore(' ').toIntOrNull() ?: 99 }.take(if (combat) 1 else multiPv)
                                                    analysisInfo = "$moveNo ход • ${(System.currentTimeMillis() - analysisStartedAt) / 1000}s • depth $depthValue • $evaluation • ${pv.split(Regex("\\s+")).firstOrNull() ?: "—"}"
                                                }
                                                if (line.startsWith("bestmove ")) break
                                            }
                                        } catch (ex: Exception) { analysisInfo = "Ошибка анализа: ${ex.message}"; logEvent("Ошибка бесконечного анализа: ${ex.message}") }
                                    }
                                } else if (e != null) {
                                    analysisRunning = false
                                    scope.launch { runCatching { e.stopSearch() }; status = "Анализ остановлен" }
                                }
                            }) { Text(if (analysisRunning) "Ⅱ" else "▶", color = Color(0xFFE1B66B), fontSize = 17.sp) }
                            IconButton(enabled = historyIndex < moveHistory.lastIndex, onClick = { historyIndex++; board.loadFromFen(moveHistory[historyIndex]); selected = null; revision++; status = "Переход вперёд по истории" }) { Text("▶|", color = Color.White, fontSize = 15.sp) }
                        }
                    }
                    item {
                        Column(Modifier.fillMaxWidth().background(Color(0xFF242C28)).border(1.dp, Color(0xFFAD7944)).padding(10.dp)) {
                            Text(analysisInfo, color = Color(0xFF8FE0B0), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            if (analysisLines.isNotEmpty()) {
                                Column(Modifier.fillMaxWidth().background(Color(0xFF171D1A)).padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    analysisLines.forEach { pvLine ->
                                        Text(pvLine, color = Color(0xFFE4EAE5), fontSize = 11.sp, lineHeight = 16.sp)
                                    }
                                }
                            } else {
                                Text("Здесь появятся варианты движка, глубина и оценка после запуска анализа.", color = Color(0xFFB9C5BE), fontSize = 11.sp)
                            }
                            OutlinedButton(enabled = engineReady && !busy, onClick = {
                                val e = engine
                                if (e != null) scope.launch {
                                    busy = true
                                    try {
                                        if (analysisRunning) { analysisRunning = false; e.stopSearch(); status = "Анализ остановлен" }
                                        e.setOption("Threads", threads.toInt().coerceAtLeast(1).toString()); e.setOption("Hash", hashMb.toInt().coerceAtLeast(16).toString()); e.setOption("Skill Level", skillLevel.toString()); e.setOption("UCI_LimitStrength", "false"); e.isReady()
                                        val best = e.bestMove(fen, depth.toInt().coerceIn(1,40), thinkSeconds.toLong().coerceAtLeast(1) * 1000L)
                                        val move = board.legalMoves().firstOrNull { it.toString().equals(best, true) }
                                        if (move != null) { board.doMove(move); lastMove = best; moveHistory = moveHistory.take(historyIndex + 1) + board.getFen(); historyIndex = moveHistory.lastIndex; revision++; status = "Применён лучший ход: $best"; logEvent("Лучший ход применён: $best") } else status = "Нет легального найденного хода: $best"
                                    } catch (ex: Exception) { status = "Ошибка лучшего хода: ${ex.message}"; logEvent("Ошибка лучшего хода: ${ex.stackTraceToString()}"); if (recoverSavedEngine()) status = "Движок восстановлен. Повтори команду." } finally { busy = false }
                                }
                            }) { Text("Применить ход из расчёта") }
                        }
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Button(modifier = Modifier.weight(1f), enabled = !busy && engineReady, onClick = {
                                val e = engine
                                if (e != null) scope.launch {
                                    busy = true
                                    try {
                                        e.setOption("Threads", threads.toInt().toString()); e.setOption("Hash", hashMb.toInt().toString()); e.setOption("Skill Level", skillLevel.toString()); e.setOption("UCI_LimitStrength", "false"); e.setOption("MultiPV", (if (combat) 1 else multiPv).toString()); e.isReady()
                                        e.setPosition(fen)
                                        val moveText = e.bestMove(fen, depth.toInt(), thinkSeconds.toLong() * 1000L)
                                        val move = board.legalMoves().firstOrNull { it.toString().equals(moveText, true) }
                                        if (move == null) status = "Движок вернул ход '$moveText', который не распознан как легальный."
                                        else { board.doMove(move); lastMove = move.toString().lowercase(); selected = null; moveHistory = moveHistory.take(historyIndex + 1) + board.getFen(); historyIndex = moveHistory.lastIndex; revision++; status = "Движок сыграл ${moveText}." }
                                    } catch (ex: Exception) { status = "Ошибка движка: ${ex.message}"; logEvent("Ошибка расчёта движка: ${ex.stackTraceToString()}"); runCatching { e.close() }; engine = null; engineReady = false; if (recoverSavedEngine()) status = "Движок восстановлен после сбоя." } finally { busy = false }
                                }
                            }) { Text(if (busy) "Расчёт…" else "Ход компьютера") }
                            OutlinedButton(modifier = Modifier.weight(1f), onClick = { fenInput = board.getFen(); status = "FEN текущей позиции подготовлен к копированию/редактированию." }) { Text("FEN позиции") }
                        }
                    }
                }
                item {
                    Column(Modifier.fillMaxWidth().background(Color(0xFF242C28)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("СТАТУС", color = Color.White, fontWeight = FontWeight.Bold)
                        Text(status, color = Color(0xFFD9E2DC), fontSize = 13.sp)
                        Text("Движок: $engineName", color = Color(0xFFB9C5BE), fontSize = 12.sp)
                        Text("FEN текущей позиции", color = Color.White, fontSize = 11.sp)
                        OutlinedTextField(value = fenInput, onValueChange = { fenInput = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Вставьте FEN для загрузки позиции") }, minLines = 2, maxLines = 3, textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { fenInput = fen; status = "FEN скопирован в поле. Выделите и скопируйте его." }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 3.dp)) { Text("Текущий FEN", fontSize = 11.sp) }
                            OutlinedButton(onClick = { runCatching { val candidate = Board(); candidate.loadFromFen(fenInput.trim()); board.loadFromFen(candidate.getFen()); selected = null; lastMove = null; moveHistory = listOf(board.getFen()); historyIndex = 0; revision++; status = "FEN загружен. История новой позиции начата." }.onFailure { status = "Некорректный FEN: ${it.message}" } }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 3.dp)) { Text("Загрузить FEN", fontSize = 11.sp) }
                            OutlinedButton(onClick = { val cb = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager; cb.setPrimaryClip(android.content.ClipData.newPlainText("FEN", fen)); status = "FEN скопирован в буфер обмена." }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 3.dp)) { Text("Копировать", fontSize = 11.sp) }
                        }
                        Text("История ходов (позиции сохраняются автоматически)", color = Color(0xFFB9C5BE), fontSize = 10.sp)
                        Text(moveHistory.take(historyIndex + 1).mapIndexedNotNull { index, position -> if (index == 0) null else "${index}. ${position.substringBefore(' ')}" }.takeLast(16).joinToString("   ").ifBlank { "Пока нет ходов" }, color = Color(0xFFD9E2DC), fontSize = 10.sp)
                    }
                }
                item { Text("Импорт поддерживает исполняемый Android-бинарник и .tar.gz/.tgz с бинарником внутри. После импорта приложение проверяет UCI и тестовый bestmove. Windows .exe, APK и архив только с исходниками не являются готовым движком.", color = Color(0xFFB9C5BE), fontSize = 11.sp) }
            }
        }
    }
}

/** Extracts the first plausible regular executable from a gzip-compressed TAR archive. */
private fun extractTarGzEngine(input: java.io.InputStream, destination: File) {
    GZIPInputStream(BufferedInputStream(input)).use { gz ->
        val header = ByteArray(512)
        var extracted = false
        while (true) {
            var read = 0
            while (read < 512) {
                val n = gz.read(header, read, 512 - read)
                if (n < 0) break
                read += n
            }
            if (read == 0 || read < 512 || header.all { it == 0.toByte() }) break
            fun field(offset: Int, length: Int): String = String(header, offset, length, Charsets.UTF_8).trimEnd('\u0000', ' ')
            val name = field(0, 100)
            val prefix = field(345, 155)
            val fullName = if (prefix.isBlank()) name else "$prefix/$name"
            val sizeText = field(124, 12).trim()
            val size = sizeText.toLongOrNull(8) ?: 0L
            val type = header[156].toInt().toChar()
            val executableCandidate = type == '\u0000' || type == '0'
            val baseName = name.substringAfterLast('/')
            // Skip docs such as Stockfish-FAQ.md (16 KB); select the actual Android ELF binary.
            val plausible = executableCandidate && size > 1_000_000L && !name.endsWith("/") &&
                (baseName.contains("android-arm64", true) || baseName.equals("stockfish", true) || baseName.contains("stockfish", true))
            if (!extracted && plausible) {
                destination.outputStream().buffered().use { out ->
                    var remaining = size
                    val buffer = ByteArray(64 * 1024)
                    while (remaining > 0) {
                        val n = gz.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                        if (n < 0) error("Архив оборван внутри файла $fullName")
                        out.write(buffer, 0, n); remaining -= n
                    }
                }
                extracted = true
            } else {
                var remaining = size
                val buffer = ByteArray(64 * 1024)
                while (remaining > 0) {
                    val n = gz.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                    if (n < 0) error("Повреждён TAR-архив")
                    remaining -= n
                }
            }
            val padding = (512 - (size % 512)) % 512
            var skip = padding
            while (skip > 0) {
                val n = gz.skip(skip)
                if (n <= 0L) { if (gz.read() < 0) error("Повреждён TAR-архив"); skip-- } else skip -= n
            }
            if (extracted) break
        }
        require(extracted) { "В .tar.gz не найден обычный файл-бинарник" }
    }
}

@Composable
private fun SettingPanel(
    engineName: String, engineReady: Boolean, optionDescriptions: List<String>, depth: Float, onDepth: (Float) -> Unit,
    seconds: Float, onSeconds: (Float) -> Unit, hash: Float, onHash: (Float) -> Unit,
    threads: Float, onThreads: (Float) -> Unit, multiPv: Int, onMultiPv: (Int) -> Unit, skillLevel: Int, onSkillLevel: (Int) -> Unit,
    combat: Boolean, onCombat: (Boolean) -> Unit, onPick: () -> Unit, debugEnabled: Boolean, onDebugEnabled: (Boolean) -> Unit, onExportLog: () -> Unit, onClearLog: () -> Unit, debugLines: List<String>, onTest: () -> Unit
) {
    val clipboard = LocalClipboardManager.current
    Column(Modifier.fillMaxWidth().background(Color(0xFF242C28)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text("ДВИЖКИ И РАСЧЁТ", color = Color.White, fontWeight = FontWeight.Bold)
        Text("Текущий движок: $engineName · ${if (engineReady) "готов" else "не подключён"}", color = Color(0xFFD9E2DC), fontSize = 12.sp)
        Button(modifier = Modifier.fillMaxWidth(), onClick = onPick) { Text("Загрузить / выбрать файл движка") }
        Text("Глубина: ${depth.toInt()} полуходов", color = Color.White); Slider(value = depth, onValueChange = onDepth, valueRange = 1f..40f, steps = 38)
        Text("Время на ход: ${seconds.toInt()} с (резерв для timed search)", color = Color.White); Slider(value = seconds, onValueChange = onSeconds, valueRange = 1f..60f, steps = 58)
        Text("Память Hash: ${hash.toInt()} МБ", color = Color.White); Slider(value = hash, onValueChange = onHash, valueRange = 16f..1024f, steps = 62)
        Text("Потоки CPU: ${threads.toInt()}", color = Color.White); Slider(value = threads, onValueChange = onThreads, valueRange = 1f..8f, steps = 6)
        Text("Главные варианты (MultiPV)", color = Color.White)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { (1..3).forEach { n -> FilterChip(selected = multiPv == n, onClick = { onMultiPv(n) }, label = { Text("$n") }) } }
        Text("Уровень Skill Level движка: $skillLevel / 20", color = Color.White); Slider(value = skillLevel.toFloat(), onValueChange = { onSkillLevel(it.toInt()) }, valueRange = 0f..20f, steps = 19)
        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = combat, onCheckedChange = onCombat); Text("Combat Mode — максимум силы", color = Color.White) }
        Text("Skill Level действует только если выбранный UCI-движок поддерживает эту опцию. Для Stockfish 19 уровень 20 — полная сила; Combat Mode включает один вариант анализа.", color = Color(0xFFB9C5BE), fontSize = 11.sp)
        Text("Опции, объявленные самим движком", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
        Text(optionDescriptions.joinToString("\n").ifBlank { "Подключите UCI-движок, чтобы прочитать его параметры." }, color = Color(0xFFD9E2DC), fontSize = 10.sp, lineHeight = 14.sp)
        Divider()
        Button(modifier = Modifier.fillMaxWidth(), onClick = onTest, enabled = engineReady, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 5.dp)) { Text("Передать настройки движку", fontSize = 12.sp) }
        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = debugEnabled, onCheckedChange = onDebugEnabled); Text("Вести журнал отладки", color = Color.White) }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { OutlinedButton(onClick = onExportLog, contentPadding = PaddingValues(horizontal = 7.dp, vertical = 3.dp)) { Text("Экспорт", fontSize = 10.sp) }; OutlinedButton(onClick = { clipboard.setText(AnnotatedString(debugLines.joinToString("\n"))) }, contentPadding = PaddingValues(horizontal = 7.dp, vertical = 3.dp)) { Text("Копировать лог", fontSize = 10.sp) }; OutlinedButton(onClick = onClearLog, contentPadding = PaddingValues(horizontal = 7.dp, vertical = 3.dp)) { Text("Очистить", fontSize = 10.sp) } }
        Text("Последние события:", color = Color.White, fontWeight = FontWeight.SemiBold)
        Text(debugLines.takeLast(12).joinToString("\n"), color = Color(0xFFB9C5BE), fontSize = 10.sp)
    }
}


@Composable
private fun GeneralSettingsPanel(gameMode: String, onGameMode: (String) -> Unit, onClose: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Color(0xFF242C28)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("НАСТРОЙКИ ПРИЛОЖЕНИЯ", color = Color.White, fontWeight = FontWeight.Bold)
        Text("Режим новой партии", color = Color(0xFFD9E2DC))
        listOf("Человек против человека", "Человек против движка", "Движок против движка").forEach { mode ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = gameMode == mode, onClick = { onGameMode(mode) })
                Text(mode, color = Color.White, fontSize = 13.sp, modifier = Modifier.clickable { onGameMode(mode) })
            }
        }
        Text("Доска: светлые фигуры с контуром, контрастные клетки и яркая розово-красная подсветка последнего хода. Настройки UCI, глубины, времени, памяти, потоков и 1–3 вариантов находятся в разделе «Движок».", color = Color(0xFFB9C5BE), fontSize = 11.sp)
        Button(onClick = onClose) { Text("Готово") }
    }
}
