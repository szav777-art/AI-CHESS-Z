# AI-CHESS-Z 1.4.0 — Analysis position synchronization

## Implemented in this package
- Bumped Android versionCode to 27 and versionName to 1.4.0-analysis-position-sync.
- Infinite-analysis coroutine tracks the game `revision`.
- When revision changes (move, undo/redo, or position load), it stops the previous UCI search, applies current engine settings, sends the latest FEN, and starts a fresh infinite search.
- Removed blind `bestmove` self-restart. UCI `bestmove` after `stop` no longer independently restarts the search; revision transition owns restart.
- Clears displayed PV rows and best move on position switch so stale lines are not presented as current.

## Not yet implemented in this ZIP
- Full PGN game database, import/export UI, replay controls and persistent game metadata.
- Full interface geometry/coordinates and score panel overhaul.
- Comprehensive UCI settings audit and engine-vs-engine regression suite.

## Verification status
- Source patch applied and archive integrity can be checked with `unzip -t`.
- Android Gradle compilation is not claimed here; validate through GitHub Actions before installing APK.
