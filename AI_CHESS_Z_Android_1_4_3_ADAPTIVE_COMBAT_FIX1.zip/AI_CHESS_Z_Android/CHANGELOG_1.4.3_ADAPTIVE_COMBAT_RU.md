# AI-CHESS-Z 1.4.3 — Adaptive Combat

- Added Android physical-RAM-aware resource policy; virtual RAM is not counted as physical memory.
- Combat Mode applies device-adaptive Threads and Hash values, capped at 4 Stockfish threads and 512 MB Hash per engine on devices with sufficient physical RAM.
- Engine-vs-engine resource budget is split per side (2 Threads / 256 MB Hash maximum on 8-core, 8-GB physical RAM class).
- Combat Mode forces MultiPV=1 and logs effective CPU/RAM profile.
- Existing user move-time/depth settings are not rewritten by the profile.

Note: final APK build and on-device thermal/performance validation must be confirmed by GitHub Actions and device testing.
