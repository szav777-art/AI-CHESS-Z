# AI-CHESS-Z 1.1.4 — UCI sync and compact controls

- UCI searches now expose a completion signal. `stopSearch()` waits for the corresponding `bestmove` before a subsequent search can start, reducing response-queue races between infinite analysis, “Сыграть лучший ход”, and “Ход компьютера”.
- Finite move searches wait on the same search completion signal instead of independently racing the output queues.
- “Ход компьютера” stops infinite analysis and waits for its completion before starting a move search.
- Engine-vs-engine AUTO toggle remains enabled while the engine is busy, is always in the same position below the board, and no longer has explanatory text below it.
- Turning AUTO off while a search is underway prevents that pending engine move from being applied to the board.
- Board rank/file coordinates remain visible in contrasting light coordinate rails and flip with the board.

## Validation status

The ZIP is structurally validated. This environment does not have a configured Android SDK/Gradle build, so APK compilation and on-device UCI behavior must still be verified by GitHub Actions and on the user's phone. The UCI synchronization changes are intended to address the observed 30-second timeouts; they are not represented as device-tested.
