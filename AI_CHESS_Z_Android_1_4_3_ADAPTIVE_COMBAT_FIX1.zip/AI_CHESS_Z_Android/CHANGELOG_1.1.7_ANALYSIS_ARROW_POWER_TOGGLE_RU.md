# AI-CHESS-Z 1.1.7

- Eight compact game controls arranged in one horizontally scrollable row: new game, flip board, best move, computer move, back, analysis, forward, auto.
- Auto button caption shortened to `АВТО`; enabled state is shown by its background.
- Power button above the board toggles between unloading the engine and loading it again.
- Engine option values are saved locally and reapplied after a reload, alongside core search settings.
- Coordinate labels use a dark background with contrasting gold text; left rank rail is wider for readability.
- Live analysis best move is displayed as `from → to`; source square shows a directional arrow and target square is dark red.
- Analysis variation panel has a maximum height and scrolls internally so it does not push the board controls too far down.

Build and device verification are not included in this source archive; verify with GitHub Actions and on-device testing.
