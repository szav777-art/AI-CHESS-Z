# Stockfish ARM64: контрольный процесс сборки

Источник:
- https://stockfishchess.org/download/
- https://github.com/official-stockfish/Stockfish
- https://official-stockfish.github.io/docs/stockfish-wiki/Compiling-from-source.html

Официальная документация описывает сборку Android через Android NDK (`COMP=ndk`) и цели `armv8` / `armv8-dotprod`. `armv8-dotprod` применим только если процессор поддерживает соответствующие инструкции. Нельзя предполагать поддержку без проверки.

Пример команд из каталога `Stockfish/src` после установки Android NDK и подготовки исходников/NNUE:
```bash
make net
make -j build ARCH=armv8 COMP=ndk
make strip ARCH=armv8 COMP=ndk
```

Для dot-product-сборки:
```bash
make clean
make -j build ARCH=armv8-dotprod COMP=ndk
make strip ARCH=armv8-dotprod COMP=ndk
```

Это пример процесса, а не готовая гарантия сборки: точные зависимости и команды необходимо сверить с выбранным commit Stockfish и версией NDK. Хранить commit ID, версию NDK, параметры сборки и SHA-256 бинарника.

Перед включением в APK:
1. проверить `file`/ELF header и ABI;
2. выполнить `sha256sum`;
3. проверить `uci`, `isready`, `position startpos`, `go depth 1`;
4. проверить `bench`;
5. сравнить силу/скорость с официальным бинарником;
6. проверить лицензионные требования GPL-3.0.
