package com.aichessz.app.engine

/** Resource policy for Android. Virtual RAM is deliberately excluded. */
data class CombatProfile(
    val enabled: Boolean,
    val multiPv: Int,
    val infiniteAnalysis: Boolean,
    val disableDecorativeAnimations: Boolean,
    val minimizeBackgroundUiWork: Boolean,
    val threads: Int,
    val hashMb: Int
) {
    companion object {
        /** Conservative 50% CPU budget, capped at four Stockfish threads. */
        fun forDevice(enabled: Boolean, mode: String, availableProcessors: Int, physicalRamMb: Long, concurrentEngines: Int = 1): CombatProfile {
            val cores = availableProcessors.coerceAtLeast(1)
            val engineCount = concurrentEngines.coerceIn(1, 2)
            val cpuBudget = (cores / 2).coerceAtLeast(1).coerceAtMost(4)
            val threads = cpuBudget.coerceAtMost((cores - 1).coerceAtLeast(1))
                .let { if (engineCount == 2) (it / 2).coerceAtLeast(1) else it }
            val perEngineHash = when {
                physicalRamMb >= 7_000 -> if (engineCount == 2) 256 else 512
                physicalRamMb >= 5_000 -> if (engineCount == 2) 192 else 384
                physicalRamMb >= 3_500 -> if (engineCount == 2) 128 else 256
                else -> if (engineCount == 2) 64 else 128
            }
            val bestMove = mode == "BEST MOVE"
            return CombatProfile(
                enabled = enabled,
                multiPv = if (enabled || bestMove) 1 else if (mode == "DEEP ANALYSIS") 3 else 1,
                infiniteAnalysis = enabled,
                disableDecorativeAnimations = enabled,
                minimizeBackgroundUiWork = enabled,
                threads = threads.coerceIn(1, 4),
                hashMb = perEngineHash
            )
        }

        /** Backward-compatible entry point for existing callers/tests. */
        fun forMode(enabled: Boolean, mode: String): CombatProfile = forDevice(
            enabled, mode, Runtime.getRuntime().availableProcessors(),
            (Runtime.getRuntime().maxMemory() / (1024 * 1024)).coerceAtLeast(2048), 1
        )
    }
}
