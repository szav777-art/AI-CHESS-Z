package com.aichessz.app.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.security.MessageDigest

/** UCI adapter for a separately imported Android ARM64 UCI engine. */
class UciEngine(private val executable: File, private val workingDirectory: File) {
    private var process: Process? = null
    private var writer: BufferedWriter? = null
    private var readerThread: Thread? = null
    // A single OS reader dispatches protocol messages to dedicated queues. Control
    // replies can no longer be stolen by the live-analysis consumer.
    private val controlLines = Channel<String>(Channel.UNLIMITED)
    private val analysisLines = Channel<String>(Channel.UNLIMITED)
    private val moveLines = Channel<String>(Channel.UNLIMITED)
    // Serialize search lifecycle commands; UCI allows only one active search.
    private val searchMutex = Mutex()
    @Volatile private var handshaking = false
    @Volatile private var infiniteSearch = false
    @Volatile private var activeSearchDone: CompletableDeferred<String>? = null
    private val supportedOptions = mutableSetOf<String>()
    private val optionDescriptions = mutableListOf<String>()
    fun advertisedOptions(): List<String> = optionDescriptions.toList()

    suspend fun start(): List<String> = withContext(Dispatchers.IO) {
        check(process == null) { "Engine already started" }
        require(executable.isFile) { "Stockfish not found: ${executable.absolutePath}" }
        require(executable.canExecute()) { "Stockfish is not executable" }
        require(workingDirectory.exists() || workingDirectory.mkdirs()) { "Cannot create engine directory" }

        val p = ProcessBuilder(executable.absolutePath)
            .directory(workingDirectory)
            .redirectErrorStream(true)
            .start()
        process = p
        writer = BufferedWriter(OutputStreamWriter(p.outputStream, Charsets.UTF_8))
        readerThread = Thread({
            try {
                BufferedReader(InputStreamReader(p.inputStream, Charsets.UTF_8)).use { r ->
                    while (!Thread.currentThread().isInterrupted) {
                        val line = r.readLine() ?: break
                        when {
                            handshaking -> { controlLines.trySend(line); if (line.trim() == "uciok") handshaking = false }
                            line.startsWith("option name ") || line.trim() == "readyok" -> controlLines.trySend(line)
                            line.startsWith("bestmove ") -> {
                                // Always wake the live-analysis consumer. During a finite engine
                                // move, bestMove() owns completion via activeSearchDone, while
                                // the analysis coroutine may be blocked in nextLine(). Without
                                // this notification it never observes the new revision and
                                // cannot restart analysis after the computer's move.
                                activeSearchDone?.complete(line)
                                analysisLines.trySend(line)
                                if (!infiniteSearch) moveLines.trySend(line)
                            }
                            else -> analysisLines.trySend(line)
                        }
                    }
                }
            } catch (_: Exception) { }
        }, "Stockfish-UCI-Reader").apply { isDaemon = true; start() }

        handshaking = true
        send("uci")
        val response = readUntil("uciok", 15_000)
        supportedOptions.clear()
        optionDescriptions.clear()
        response.filter { it.startsWith("option name ") }.forEach { line ->
            optionDescriptions += line
            val name = line.removePrefix("option name ").substringBefore(" type ").trim()
            if (name.isNotBlank()) supportedOptions += name.lowercase()
        }
        response
    }

    suspend fun isReady(): List<String> {
        send("isready")
        return readUntil("readyok", 30_000)
    }

    /** Full smoke test: negotiate UCI, wait for readiness, and calculate one legal move. */
    suspend fun selfTest(): List<String> {
        try {
            val handshake = start()
            val ready = isReady()
            send("position startpos")
            infiniteSearch = false
            send("go depth 1")
            val best = withTimeout(20_000) { moveLines.receive() }
            check(best.startsWith("bestmove ")) { "Stockfish did not return bestmove" }
            return handshake + ready + listOf(best)
        } catch (error: Throwable) {
            runCatching { close() }
            throw error
        }
    }

    /** Calculates a move for the supplied current position. Requires a completed UCI handshake. */
    suspend fun bestMove(fen: String, depth: Int = 12, moveTimeMs: Long? = null): String = searchMutex.withLock {
        require(depth in 1..40) { "Depth must be between 1 and 40" }
        require(moveTimeMs == null || moveTimeMs in 100L..600_000L) { "Move time must be between 100 ms and 600000 ms" }
        // Exactly one coroutine owns the search lifecycle at a time.
        if (activeSearchDone?.isCompleted == false) stopSearchInternal()
        while (moveLines.tryReceive().isSuccess) { }
        // Keep analysisLines owned by the live-analysis consumer; draining it
        // here can steal the stop bestmove and desynchronize continuous analysis.
        infiniteSearch = false
        val done = CompletableDeferred<String>()
        activeSearchDone = done
        send("position fen $fen")
        send(if (moveTimeMs != null) "go movetime $moveTimeMs" else "go depth $depth")
        val line = withTimeout(620_000) { done.await() }
        line.removePrefix("bestmove ").trim().split(Regex("\\s+"))[0]
    }

    suspend fun setOption(name: String, value: String) {
        // Different UCI engines expose different option sets. Never send an option the engine did not advertise.
        if (name.lowercase() in supportedOptions) send("setoption name $name value $value")
    }

    /** Executes an advertised UCI button option such as Clear Hash (no value field). */
    suspend fun pressOption(name: String) {
        if (name.lowercase() in supportedOptions) send("setoption name $name")
    }
    suspend fun setPosition(fen: String) = send("position fen $fen")
    suspend fun setPosition(fen: String, moves: List<String>) {
        send("position fen $fen" + if (moves.isEmpty()) "" else " moves ${moves.joinToString(" ")}")
    }
    suspend fun startInfiniteAnalysis() = searchMutex.withLock {
        if (activeSearchDone?.isCompleted == false) stopSearchInternal()
        while (analysisLines.tryReceive().isSuccess) { }
        while (moveLines.tryReceive().isSuccess) { }
        infiniteSearch = true
        activeSearchDone = CompletableDeferred()
        send("go infinite")
    }

    /** Serializes stop with start/bestMove and waits for the matching bestmove. */
    suspend fun stopSearch() = searchMutex.withLock { stopSearchInternal() }

    /** True while the OS process is running; false after close/emergency stop. */
    fun isAlive(): Boolean = process?.isAlive == true

    /**
     * True after a stop request was not acknowledged. Such an engine is presumed
     * wedged (for example after setoption was sent during an active search, which
     * blocks the UCI command loop) and must be recreated by the UI layer.
     */
    @Volatile var wedged = false
        private set

    private suspend fun stopSearchInternal() {
        val pending = activeSearchDone
        if (pending == null || pending.isCompleted) {
            infiniteSearch = false
            return
        }
        if (wedged) {
            // A previous stop was never acknowledged: the engine's UCI loop is
            // blocked. Fail fast instead of waiting another 30 seconds; the UI
            // recreates the engine via recoverSavedEngine().
            activeSearchDone = null
            infiniteSearch = false
            throw IllegalStateException("Engine did not acknowledge the previous stop; restart required")
        }
        send("stop")
        try {
            withTimeout(30_000) { pending.await() }
        } catch (e: TimeoutCancellationException) {
            wedged = true
            throw IllegalStateException("Stockfish did not finish the stopped search within 30 seconds", e)
        } finally {
            infiniteSearch = false
        }
    }

    suspend fun newGame() { send("ucinewgame"); isReady() }

    /** Read live UCI output (info/bestmove); returns null if the engine has closed. */
    suspend fun nextLine(): String? = analysisLines.receiveCatching().getOrNull()

    /**
     * Emergency path for a stuck native engine. Does not wait for UCI "bestmove"
     * or "quit": kills the OS process immediately so the UI can recover.
     * A terminated UciEngine instance must not be reused; create a new one.
     */
    @Synchronized
    fun emergencyTerminate() {
        infiniteSearch = false
        activeSearchDone?.let { done ->
            if (!done.isCompleted) done.completeExceptionally(
                IllegalStateException("Engine process terminated by emergency stop")
            )
        }
        val p = process
        process = null
        writer = null
        runCatching { p?.destroyForcibly() }
        runCatching { readerThread?.interrupt() }
        readerThread = null
        runCatching { controlLines.close() }
        runCatching { analysisLines.close() }
        runCatching { moveLines.close() }
    }

    suspend fun close() = withContext(Dispatchers.IO) {
        runCatching { stopSearch() }
        runCatching { send("quit") }
        val p = process
        if (p != null && p.isAlive) {
            val exited = runCatching { p.waitFor(1500, java.util.concurrent.TimeUnit.MILLISECONDS) }.getOrDefault(false)
            if (!exited) runCatching { p.destroyForcibly() }
        }
        runCatching { readerThread?.interrupt() }
        writer = null
        process = null
        readerThread = null
        controlLines.close()
        analysisLines.close()
        moveLines.close()
    }

    private suspend fun readUntil(marker: String, timeoutMs: Long): List<String> =
        readUntilMatching(timeoutMs) { it.trim() == marker }

    private suspend fun readUntilPrefix(prefix: String, timeoutMs: Long): List<String> =
        readUntilMatching(timeoutMs) { it.startsWith(prefix) }

    private suspend fun readUntilMatching(timeoutMs: Long, matches: (String) -> Boolean): List<String> = withTimeout(timeoutMs) {
        val result = mutableListOf<String>()
        var matched = false
        while (!matched) {
            val line = controlLines.receive()
            result += line
            matched = matches(line)
        }
        result
    }

    private fun send(command: String) {
        check(process != null && process?.isAlive == true) { "Engine is not running" }
        val w = writer ?: error("Engine not started")
        synchronized(w) {
            w.write(command)
            w.newLine()
            w.flush()
        }
    }

    companion object {
        fun bundledExecutable(nativeLibraryDir: String): File = File(nativeLibraryDir, "libstockfish.so")
        fun sha256(file: File): String {
            val digest = MessageDigest.getInstance("SHA-256")
            file.inputStream().use { input ->
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    digest.update(buffer, 0, count)
                }
            }
            return digest.digest().joinToString("") { "%02x".format(it) }
        }
    }
}
