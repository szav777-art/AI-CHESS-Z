package com.aichessz.app.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.security.MessageDigest

/** UCI adapter for the bundled, verified Android ARM64 Stockfish executable. */
class UciEngine(private val executable: File, private val workingDirectory: File) {
    private var process: Process? = null
    private var writer: BufferedWriter? = null
    private var readerThread: Thread? = null
    private val lines = Channel<String>(Channel.UNLIMITED)
    private val supportedOptions = mutableSetOf<String>()
    private val optionDescriptions = mutableListOf<String>()
    fun advertisedOptions(): List<String> = optionDescriptions.toList()

    suspend fun start(): List<String> = withContext(Dispatchers.IO) {
        check(process == null) { "Engine already started" }
        require(executable.isFile) { "Stockfish not found: ${executable.absolutePath}" }
        require(executable.canExecute()) { "Stockfish is not executable" }
        require(workingDirectory.exists() || workingDirectory.mkdirs()) { "Cannot create engine directory" }

        val p = ProcessBuilder(executable.absolutePath)
            .directory(workingDirectory)
            .redirectErrorStream(true)
            .start()
        process = p
        writer = BufferedWriter(OutputStreamWriter(p.outputStream, Charsets.UTF_8))
        readerThread = Thread({
            try {
                BufferedReader(InputStreamReader(p.inputStream, Charsets.UTF_8)).use { r ->
                    while (!Thread.currentThread().isInterrupted) {
                        val line = r.readLine() ?: break
                        lines.trySend(line)
                    }
                }
            } catch (_: Exception) { }
        }, "Stockfish-UCI-Reader").apply { isDaemon = true; start() }

        send("uci")
        val response = readUntil("uciok", 15_000)
        supportedOptions.clear()
        optionDescriptions.clear()
        response.filter { it.startsWith("option name ") }.forEach { line ->
            optionDescriptions += line
            val name = line.removePrefix("option name ").substringBefore(" type ").trim()
            if (name.isNotBlank()) supportedOptions += name.lowercase()
        }
        response
    }

    suspend fun isReady(): List<String> {
        send("isready")
        return readUntil("readyok", 30_000)
    }

    /** Full smoke test: negotiate UCI, wait for readiness, and calculate one legal move. */
    suspend fun selfTest(): List<String> {
        try {
            val handshake = start()
            val ready = isReady()
            send("position startpos")
            send("go depth 1")
            val search = readUntilPrefix("bestmove ", 20_000)
            check(search.any { it.startsWith("bestmove ") }) { "Stockfish did not return bestmove" }
            return handshake + ready + search
        } catch (error: Throwable) {
            runCatching { close() }
            throw error
        }
    }

    /** Calculates a move for the supplied current position. Requires a completed UCI handshake. */
    suspend fun bestMove(fen: String, depth: Int = 12, moveTimeMs: Long? = null): String {
        require(depth in 1..40) { "Depth must be between 1 and 40" }
        require(moveTimeMs == null || moveTimeMs in 100L..600_000L) { "Move time must be between 100 ms and 600000 ms" }
        send("position fen $fen")
        send(if (moveTimeMs != null) "go depth $depth movetime $moveTimeMs" else "go depth $depth")
        val line = readUntilPrefix("bestmove ", 620_000).lastOrNull { it.startsWith("bestmove ") }
            ?: error("Stockfish did not return bestmove")
        return line.removePrefix("bestmove ").trim().split(Regex("\\s+"))[0]
    }

    suspend fun setOption(name: String, value: String) {
        // Different UCI engines expose different option sets. Never send an option the engine did not advertise.
        if (name.lowercase() in supportedOptions) send("setoption name $name value $value")
    }

    /** Executes an advertised UCI button option such as Clear Hash (no value field). */
    suspend fun pressOption(name: String) {
        if (name.lowercase() in supportedOptions) send("setoption name $name")
    }
    suspend fun setPosition(fen: String) = send("position fen $fen")
    suspend fun setPosition(fen: String, moves: List<String>) {
        send("position fen $fen" + if (moves.isEmpty()) "" else " moves ${moves.joinToString(" ")}")
    }
    suspend fun startInfiniteAnalysis() = send("go infinite")
    suspend fun stopSearch() = send("stop")
    suspend fun newGame() { send("ucinewgame"); isReady() }

    /** Read live UCI output (info/bestmove); returns null if the engine has closed. */
    suspend fun nextLine(): String? = lines.receiveCatching().getOrNull()

    suspend fun close() = withContext(Dispatchers.IO) {
        runCatching { send("stop") }
        runCatching { send("quit") }
        val p = process
        if (p != null && p.isAlive) {
            val exited = runCatching { p.waitFor(1500, java.util.concurrent.TimeUnit.MILLISECONDS) }.getOrDefault(false)
            if (!exited) runCatching { p.destroyForcibly() }
        }
        runCatching { readerThread?.interrupt() }
        writer = null
        process = null
        readerThread = null
        lines.close()
    }

    private suspend fun readUntil(marker: String, timeoutMs: Long): List<String> =
        readUntilMatching(timeoutMs) { it.trim() == marker }

    private suspend fun readUntilPrefix(prefix: String, timeoutMs: Long): List<String> =
        readUntilMatching(timeoutMs) { it.startsWith(prefix) }

    private suspend fun readUntilMatching(timeoutMs: Long, matches: (String) -> Boolean): List<String> = withTimeout(timeoutMs) {
        val result = mutableListOf<String>()
        var matched = false
        while (!matched) {
            val line = lines.receive()
            result += line
            matched = matches(line)
        }
        result
    }

    private fun send(command: String) {
        check(process != null && process?.isAlive == true) { "Engine is not running" }
        val w = writer ?: error("Engine not started")
        synchronized(w) {
            w.write(command)
            w.newLine()
            w.flush()
        }
    }

    companion object {
        fun bundledExecutable(nativeLibraryDir: String): File = File(nativeLibraryDir, "libstockfish.so")
        fun sha256(file: File): String {
            val digest = MessageDigest.getInstance("SHA-256")
            file.inputStream().use { input ->
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    digest.update(buffer, 0, count)
                }
            }
            return digest.digest().joinToString("") { "%02x".format(it) }
        }
    }
}
