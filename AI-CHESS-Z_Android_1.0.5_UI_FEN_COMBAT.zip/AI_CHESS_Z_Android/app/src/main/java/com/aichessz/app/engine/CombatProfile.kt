package com.aichessz.app.engine

/**
 * UI-level profile. Actual UCI options must be queried from the selected engine;
 * never send unsupported options blindly.
 */
data class CombatProfile(
    val enabled: Boolean,
    val multiPv: Int,
    val infiniteAnalysis: Boolean,
    val disableDecorativeAnimations: Boolean,
    val minimizeBackgroundUiWork: Boolean
) {
    companion object {
        fun forMode(enabled: Boolean, mode: String): CombatProfile {
            val bestMove = mode == "BEST MOVE"
            return CombatProfile(
                enabled = enabled,
                multiPv = if (enabled && bestMove) 1 else if (mode == "DEEP ANALYSIS") 3 else 1,
                infiniteAnalysis = enabled,
                disableDecorativeAnimations = enabled,
                minimizeBackgroundUiWork = enabled
            )
        }
    }
}
