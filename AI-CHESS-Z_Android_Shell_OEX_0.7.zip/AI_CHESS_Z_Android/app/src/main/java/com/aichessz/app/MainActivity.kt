package com.aichessz.app

import android.os.Bundle
import android.content.Intent
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Square
import com.github.bhlangonijr.chesslib.move.Move

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AiChessZApp() }
    }
}

private val lightSquare = Color(0xFFE9E5DC)
private val darkSquare = Color(0xFF91A092)
private val whitePiece = Color(0xFFFAFAF7)
private val blackPiece = Color(0xFF17211D)
private val selectedSquare = Color(0xFFD8B45C)
private val lastMoveSquare = Color(0xFFB9C9A6)
private val whiteSymbols = mapOf("WHITE_KING" to "♔", "WHITE_QUEEN" to "♕", "WHITE_ROOK" to "♖", "WHITE_BISHOP" to "♗", "WHITE_KNIGHT" to "♘", "WHITE_PAWN" to "♙")
private val blackSymbols = mapOf("BLACK_KING" to "♚", "BLACK_QUEEN" to "♛", "BLACK_ROOK" to "♜", "BLACK_BISHOP" to "♝", "BLACK_KNIGHT" to "♞", "BLACK_PAWN" to "♟")

@Composable
private fun AiChessZApp() {
    val context = LocalContext.current
    val board = remember { Board() }
    var revision by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<String?>(null) }
    var lastMove by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("Офлайн. Белые ходят первыми.") }
    var providers by remember { mutableStateOf<List<String>>(emptyList()) }
    var scanDone by remember { mutableStateOf(false) }
    val legalMoves = remember(revision) { board.legalMoves() }
    val targets = remember(selected, revision) {
        legalMoves.filter { selected != null && it.toString().lowercase().startsWith(selected!!.lowercase()) }
            .map { it.toString().substring(2, 4).lowercase() }.toSet()
    }
    val currentFen = remember(revision) { board.getFen() }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF171C1A)) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("AI-CHESS-Z", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                            Text("OFFLINE · ENGINE-READY SHELL", color = Color(0xFFB9C5BE), fontSize = 11.sp)
                        }
                        Text("0.7 SHELL", color = Color(0xFFB9C5BE), fontSize = 11.sp)
                    }
                }
                item {
                    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("8", color = Color(0xFFCFD8D2), fontSize = 11.sp)
                            Text("1", color = Color(0xFFCFD8D2), fontSize = 11.sp)
                        }
                        Column(modifier = Modifier.fillMaxWidth().aspectRatio(1f)) {
                            for (rank in 8 downTo 1) {
                                Row(modifier = Modifier.weight(1f)) {
                                    for (file in 'A'..'H') {
                                        val sq = "$file$rank"
                                        val pieceName = board.getPiece(Square.valueOf(sq)).toString()
                                        val symbol = whiteSymbols[pieceName] ?: blackSymbols[pieceName] ?: ""
                                        val base = if (((file - 'A') + rank) % 2 == 0) darkSquare else lightSquare
                                        val bg = when {
                                            selected == sq.lowercase() -> selectedSquare
                                            sq.lowercase() in targets -> Color(0xFFC6D5AE)
                                            lastMove?.let { sq.lowercase() == it.substring(0, 2) || sq.lowercase() == it.substring(2, 4) } == true -> lastMoveSquare
                                            else -> base
                                        }
                                        Box(
                                            modifier = Modifier.weight(1f).aspectRatio(1f).background(bg).clickable {
                                                
                                                val current = selected
                                                if (current == null) {
                                                    val side = board.getPiece(Square.valueOf(sq)).toString()
                                                    val isWhiteToMove = board.getSideToMove().toString() == "WHITE"
                                                    if (side != "NONE" && side != "null" && side.startsWith(if (isWhiteToMove) "WHITE" else "BLACK")) selected = sq.lowercase()
                                                } else {
                                                    val move = legalMoves.firstOrNull {
                                                        it.toString().lowercase().startsWith(current + sq.lowercase()) &&
                                                            (it.toString().length <= 4 || it.toString().endsWith("q", true))
                                                    }
                                                    if (move != null) {
                                                        runCatching { board.doMove(move) }
                                                            .onSuccess {
                                                                lastMove = move.toString().lowercase()
                                                                revision++
                                                                status = "Ход ${move.toString().lowercase()} · ${if (board.isMated()) "мат" else "ход ${board.getSideToMove()}"}"
                                                            }
                                                        selected = null
                                                    } else {
                                                        val piece = board.getPiece(Square.valueOf(sq)).toString()
                                                        val whiteTurn = board.getSideToMove().toString() == "WHITE"
                                                        if (piece.startsWith(if (whiteTurn) "WHITE" else "BLACK")) selected = sq.lowercase() else selected = null
                                                    }
                                                }
                                            },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (symbol.isNotEmpty()) Text(
                                                symbol,
                                                color = if (pieceName.startsWith("WHITE")) whitePiece else blackPiece,
                                                fontSize = 29.sp,
                                                fontWeight = FontWeight.Black,
                                                lineHeight = 30.sp
                                            )
                                            if (sq.lowercase() in targets && symbol.isEmpty()) {
                                                Box(Modifier.fillMaxSize().padding(23.dp).background(Color(0x66556B45)))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            "abcdefgh".forEach { Text(it.toString(), color = Color(0xFFCFD8D2), fontSize = 12.sp) }
                        }
                    }
                }
                item {
                    Column(modifier = Modifier.fillMaxWidth().background(Color(0xFF242C28)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("СТАТУС", color = Color.White, fontWeight = FontWeight.Bold)
                        Text(status, color = Color(0xFFD9E2DC), fontSize = 13.sp)
                        Text("FEN: $currentFen", color = Color(0xFFB9C5BE), fontSize = 10.sp)
                    }
                }
                item {
                    Button(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            val intent = Intent("intent.chess.provider.ENGINE")
                            val matches = context.packageManager.queryIntentActivities(intent, 0)
                            providers = matches.mapNotNull { info ->
                                val label = info.loadLabel(context.packageManager)?.toString()?.trim().orEmpty()
                                if (label.isBlank()) info.activityInfo.packageName else label
                            }.distinct().sorted()
                            scanDone = true
                            status = if (providers.isEmpty()) {
                                "OEX-движки не обнаружены. Установи отдельный совместимый движок, затем проверь снова."
                            } else {
                                "Найдено OEX-провайдеров: ${providers.size}. Обнаружение работает; подключение UCI ещё не реализовано."
                            }
                        }
                    ) { Text("Найти установленные движки OEX") }
                }
                if (scanDone) {
                    item {
                        Column(
                            modifier = Modifier.fillMaxWidth().background(Color(0xFF242C28)).padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Text("ВНЕШНИЕ ДВИЖКИ", color = Color.White, fontWeight = FontWeight.Bold)
                            if (providers.isEmpty()) {
                                Text("Совместимые OEX-провайдеры пока не найдены.", color = Color(0xFFD9E2DC), fontSize = 13.sp)
                            } else {
                                providers.forEach { provider ->
                                    Text("• $provider", color = Color(0xFFD9E2DC), fontSize = 13.sp)
                                }
                            }
                            Text("Важно: текущий этап обнаруживает установленные OEX-приложения, но ещё не передаёт им позицию и не получает ходы.", color = Color(0xFFB9C5BE), fontSize = 11.sp)
                        }
                    }
                }
                item {
                    Button(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            runCatching {
                                board.loadFromFen(Board().getFen())
                                selected = null
                                lastMove = null
                                revision++
                                status = "Новая партия. Белые ходят первыми."
                            }.onFailure { status = "Не удалось начать новую партию: ${it.message}" }
                        }
                    ) { Text("Новая партия") }
                }
                item {
                    Text("Этап 0.7: лёгкая оболочка без встроенного движка. OEX-поиск — предварительный; полноценный обмен UCI и установка APK требуют отдельной проверки.", color = Color(0xFFB9C5BE), fontSize = 11.sp)
                }
            }
        }
    }
}
