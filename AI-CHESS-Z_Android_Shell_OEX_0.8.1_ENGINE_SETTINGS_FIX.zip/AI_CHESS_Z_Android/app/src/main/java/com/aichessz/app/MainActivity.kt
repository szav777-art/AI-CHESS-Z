package com.aichessz.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.aichessz.app.engine.UciEngine
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Square
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { AiChessZApp() } }
}

private val lightSquare = Color(0xFFE9E5DC)
private val darkSquare = Color(0xFF718778)
private val whitePiece = Color(0xFFFAFAF7)
private val blackPiece = Color(0xFF17211D)
private val whiteSymbols = mapOf("WHITE_KING" to "♔", "WHITE_QUEEN" to "♕", "WHITE_ROOK" to "♖", "WHITE_BISHOP" to "♗", "WHITE_KNIGHT" to "♘", "WHITE_PAWN" to "♙")
private val blackSymbols = mapOf("BLACK_KING" to "♚", "BLACK_QUEEN" to "♛", "BLACK_ROOK" to "♜", "BLACK_BISHOP" to "♝", "BLACK_KNIGHT" to "♞", "BLACK_PAWN" to "♟")

@Composable
private fun AiChessZApp() {
    val context = LocalContext.current
    val board = remember { Board() }
    val scope = rememberCoroutineScope()
    var revision by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<String?>(null) }
    var lastMove by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("Готово. Выберите фигуру или подключите движок в настройках.") }
    var engineFile by remember { mutableStateOf<File?>(null) }
    var engineName by remember { mutableStateOf("Движок не выбран") }
    var engineReady by remember { mutableStateOf(false) }
    var depth by remember { mutableFloatStateOf(12f) }
    var thinkSeconds by remember { mutableFloatStateOf(5f) }
    var hashMb by remember { mutableFloatStateOf(128f) }
    var threads by remember { mutableFloatStateOf(2f) }
    var multiPv by remember { mutableIntStateOf(1) }
    var combat by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var engine by remember { mutableStateOf<UciEngine?>(null) }
    val legalMoves = remember(revision) { board.legalMoves() }
    val targets = remember(selected, revision) { legalMoves.filter { selected != null && it.toString().lowercase().startsWith(selected!!) }.map { it.toString().substring(2,4).lowercase() }.toSet() }
    val fen = remember(revision) { board.getFen() }

    val pickEngine = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                busy = true; engineReady = false
                try {
                    val dir = File(context.filesDir, "engines").apply { mkdirs() }
                    val name = (uri.lastPathSegment ?: "engine").substringAfterLast('/').substringAfterLast(':').replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "engine.bin" }
                    val dest = File(dir, name)
                    withContext(Dispatchers.IO) { context.contentResolver.openInputStream(uri).use { input -> requireNotNull(input) { "Не удалось открыть файл" }; dest.outputStream().use { output -> input.copyTo(output) } } }
                    dest.setExecutable(true, true)
                    engine?.let { runCatching { it.close() } }
                    val candidate = UciEngine(dest, dir)
                    val handshake = candidate.start()
                    require(handshake.any { it.trim() == "uciok" }) { "Файл не ответил на протокол UCI" }
                    candidate.isReady()
                    engine = candidate; engineFile = dest; engineName = dest.name; engineReady = true
                    status = "Движок подключён: ${dest.name}. UCI готов."
                } catch (e: Exception) {
                    engineReady = false; engine = null
                    status = "Не удалось запустить движок: ${e.message ?: e.javaClass.simpleName}. Нужен исполняемый Android-бинарник, совместимый с телефоном, и протокол UCI."
                } finally { busy = false }
            }
        }
    }

    MaterialTheme {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF171C1A)) {
            LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("AI-CHESS-Z", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                            Text("LOCAL ENGINE · UCI · OFFLINE", color = Color(0xFFB9C5BE), fontSize = 11.sp)
                        }
                        Button(onClick = { showSettings = !showSettings }) { Text(if (showSettings) "К доске" else "Настройки") }
                    }
                }
                if (showSettings) {
                    item { SettingPanel(
                        engineName = engineName, engineReady = engineReady, depth = depth, onDepth = { depth = it }, seconds = thinkSeconds, onSeconds = { thinkSeconds = it }, hash = hashMb, onHash = { hashMb = it }, threads = threads, onThreads = { threads = it }, multiPv = multiPv, onMultiPv = { multiPv = it }, combat = combat, onCombat = { combat = it }, onPick = { pickEngine.launch(arrayOf("*/*")) }, onTest = {
                            val e = engine
                            if (e == null || !engineReady) status = "Сначала выберите совместимый UCI-движок."
                            else scope.launch {
                                busy = true
                                try {
                                    e.setOption("Threads", (if (combat) threads.toInt().coerceAtLeast(2) else threads.toInt()).toString()); e.setOption("Hash", hashMb.toInt().toString()); e.setOption("MultiPV", (if (combat) 1 else multiPv).toString()); e.isReady()
                                    status = "Настройки переданы движку. Нажмите «Ход компьютера» для проверки расчёта."
                                } catch (ex: Exception) { status = "Ошибка настройки: ${ex.message}" } finally { busy = false }
                            }
                        }) }
                } else {
                    item {
                        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                            Column(Modifier.fillMaxWidth().aspectRatio(1f)) {
                                for (rank in 8 downTo 1) Row(Modifier.weight(1f)) {
                                    for (file in 'A'..'H') {
                                        val sq = "$file$rank"; val low = sq.lowercase()
                                        val pieceName = board.getPiece(Square.valueOf(sq)).toString()
                                        val symbol = whiteSymbols[pieceName] ?: blackSymbols[pieceName] ?: ""
                                        val base = if (((file - 'A') + rank) % 2 == 0) darkSquare else lightSquare
                                        val bg = when { selected == low -> Color(0xFFE5B84B); low in targets -> Color(0xFFB5D69C); lastMove?.let { low == it.take(2) || low == it.substring(2,4) } == true -> Color(0xFF9EBAA1); else -> base }
                                        Box(Modifier.weight(1f).aspectRatio(1f).background(bg).clickable {
                                            val current = selected
                                            if (current == null) {
                                                val piece = board.getPiece(Square.valueOf(sq)).toString(); val whiteTurn = board.getSideToMove().toString() == "WHITE"
                                                if (piece.startsWith(if (whiteTurn) "WHITE" else "BLACK")) selected = low
                                            } else {
                                                val move = legalMoves.firstOrNull { it.toString().lowercase().startsWith(current + low) && (it.toString().length <= 4 || it.toString().endsWith("q", true)) }
                                                if (move != null) { runCatching { board.doMove(move) }.onSuccess { lastMove = move.toString().lowercase(); revision++; status = "Ход ${move.toString().lowercase()} · ${if (board.isMated()) "мат" else "ход ${board.getSideToMove()}"}" }; selected = null }
                                                else { val piece = board.getPiece(Square.valueOf(sq)).toString(); val whiteTurn = board.getSideToMove().toString() == "WHITE"; selected = if (piece.startsWith(if (whiteTurn) "WHITE" else "BLACK")) low else null }
                                            }
                                        }, contentAlignment = Alignment.Center) {
                                            if (symbol.isNotEmpty()) Text(symbol, color = if (pieceName.startsWith("WHITE")) whitePiece else blackPiece, fontSize = 30.sp, fontWeight = FontWeight.Black)
                                            if (low in targets && symbol.isEmpty()) Box(Modifier.size(14.dp).background(Color(0x99556B45)))
                                        }
                                    }
                                }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) { "abcdefgh".forEach { Text(it.toString(), color = Color(0xFFCFD8D2), fontSize = 12.sp) } }
                        }
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Button(modifier = Modifier.weight(1f), enabled = !busy && engineReady, onClick = {
                                val e = engine
                                if (e != null) scope.launch {
                                    busy = true
                                    try {
                                        e.setOption("Threads", threads.toInt().toString()); e.setOption("Hash", hashMb.toInt().toString()); e.setOption("MultiPV", (if (combat) 1 else multiPv).toString()); e.isReady()
                                        e.setPosition(fen)
                                        val moveText = e.bestMove(fen, depth.toInt(), thinkSeconds.toLong() * 1000L)
                                        val move = board.legalMoves().firstOrNull { it.toString().equals(moveText, true) }
                                        if (move == null) status = "Движок вернул ход '$moveText', который не распознан как легальный."
                                        else { board.doMove(move); lastMove = move.toString().lowercase(); selected = null; revision++; status = "Движок сыграл ${moveText}." }
                                    } catch (ex: Exception) { status = "Ошибка движка: ${ex.message}" } finally { busy = false }
                                }
                            }) { Text(if (busy) "Расчёт…" else "Ход компьютера") }
                            Button(modifier = Modifier.weight(1f), onClick = { board.loadFromFen(Board().getFen()); selected = null; lastMove = null; revision++; status = "Новая партия. Белые ходят первыми." }) { Text("Новая партия") }
                        }
                    }
                    item { Button(modifier = Modifier.fillMaxWidth(), onClick = { showSettings = true }) { Text("Настройки и движки") } }
                }
                item {
                    Column(Modifier.fillMaxWidth().background(Color(0xFF242C28)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("СТАТУС", color = Color.White, fontWeight = FontWeight.Bold)
                        Text(status, color = Color(0xFFD9E2DC), fontSize = 13.sp)
                        Text("Движок: $engineName", color = Color(0xFFB9C5BE), fontSize = 12.sp)
                        Text("FEN: $fen", color = Color(0xFFB9C5BE), fontSize = 10.sp)
                    }
                }
                item { Text("Импорт движка принимает файл, но запустятся только исполняемые Android-бинарники подходящей ABI, поддерживающие UCI. Windows .exe, обычный APK и исходный ZIP движком не являются.", color = Color(0xFFB9C5BE), fontSize = 11.sp) }
            }
        }
    }
}

@Composable
private fun SettingPanel(
    engineName: String, engineReady: Boolean, depth: Float, onDepth: (Float) -> Unit,
    seconds: Float, onSeconds: (Float) -> Unit, hash: Float, onHash: (Float) -> Unit,
    threads: Float, onThreads: (Float) -> Unit, multiPv: Int, onMultiPv: (Int) -> Unit,
    combat: Boolean, onCombat: (Boolean) -> Unit, onPick: () -> Unit, onTest: () -> Unit
) {
    Column(Modifier.fillMaxWidth().background(Color(0xFF242C28)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text("ДВИЖКИ И РАСЧЁТ", color = Color.White, fontWeight = FontWeight.Bold)
        Text("Текущий движок: $engineName · ${if (engineReady) "готов" else "не подключён"}", color = Color(0xFFD9E2DC), fontSize = 12.sp)
        Button(modifier = Modifier.fillMaxWidth(), onClick = onPick) { Text("Загрузить / выбрать файл движка") }
        Text("Глубина: ${depth.toInt()} полуходов", color = Color.White); Slider(value = depth, onValueChange = onDepth, valueRange = 1f..40f, steps = 38)
        Text("Время на ход: ${seconds.toInt()} с (резерв для timed search)", color = Color.White); Slider(value = seconds, onValueChange = onSeconds, valueRange = 1f..60f, steps = 58)
        Text("Память Hash: ${hash.toInt()} МБ", color = Color.White); Slider(value = hash, onValueChange = onHash, valueRange = 16f..1024f, steps = 62)
        Text("Потоки CPU: ${threads.toInt()}", color = Color.White); Slider(value = threads, onValueChange = onThreads, valueRange = 1f..8f, steps = 6)
        Text("Главные варианты (MultiPV)", color = Color.White)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { (1..3).forEach { n -> FilterChip(selected = multiPv == n, onClick = { onMultiPv(n) }, label = { Text("$n") }) } }
        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = combat, onCheckedChange = onCombat); Text("Режим максимальной силы", color = Color.White) }
        Text("Режим максимальной силы фиксирует 1 вариант и максимизирует потоки в рамках выбранного лимита; не гарантирует максимальную силу на перегретом телефоне.", color = Color(0xFFB9C5BE), fontSize = 11.sp)
        Button(modifier = Modifier.fillMaxWidth(), onClick = onTest, enabled = engineReady) { Text("Применить настройки движка") }
    }
}
